#ifndef FUNCGEN_H
#define FUNCGEN_H


class funcGen
{
public:
    funcGen();

    void send_voltage(float);
};

#endif // FUNCGEN_H
