#ifndef TIMER_TESTING_H
#define TIMER_TESTING_H

#include <QMainWindow>

namespace Ui {
class timer_testing;
}

class timer_testing : public QMainWindow
{
    Q_OBJECT

public:
    explicit timer_testing(QWidget *parent = 0);
    ~timer_testing();

private:
    Ui::timer_testing *ui;

private slots:
    void print();
    void print2();
    void on_setTimer_clicked();
};

#endif // TIMER_TESTING_H
