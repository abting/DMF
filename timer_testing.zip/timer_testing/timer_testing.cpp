#include "timer_testing.h"
#include "ui_timer_testing.h"
#include <QTimer>
#include <QThread>
#include <QTime>

int timeElapsed;
int timeElapsed2;

QTimer *timer2;
QTimer *timer;
QTime countdown;

timer_testing::timer_testing(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::timer_testing)
{
    ui->setupUi(this);
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this,SLOT(print()));
    timer->start(1000);

    timer2 = new QTimer(this);
    connect(timer2, SIGNAL(timeout()),this,SLOT(print2()));

    ui->hourEdit->setText("00");
    ui->minuteEdit->setText("00");
    ui->secondEdit->setText("00");

}

timer_testing::~timer_testing()
{
    delete ui;
}

void timer_testing::print(){
    timeElapsed++;
    ui->eventEdit->insertPlainText("\n"+QString::number(timeElapsed));
}

void timer_testing::print2(){
    countdown = countdown.addSecs(-1);
    if (countdown.hour()==0 &&countdown.minute()==0&&countdown.second()==0){
        ui->eventEdit->setText("DONE!");
        timer2->stop();
        timer->stop();
    }
    ui->hourEdit->setText(QString::number(countdown.hour()));
    ui->minuteEdit->setText(QString::number(countdown.minute()));
    ui->secondEdit->setText(QString::number(countdown.second()));
}

void timer_testing::on_setTimer_clicked()
{
    QThread *thread1 = new QThread;
    thread1->start();
    int hour = ui->hourEdit->text().toInt();
    int minute = ui->minuteEdit->text().toInt();
    int second = ui->secondEdit->text().toInt();

    countdown.setHMS(hour,minute,second);

    timer2->start(1000);
    timer2->moveToThread(thread1);
}
