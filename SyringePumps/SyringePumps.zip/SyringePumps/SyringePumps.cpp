// SyringePumps.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

//===========================================================================
//                               INCLUDES
//===========================================================================
#include "nemesys_api.h"
#include "err_codes.h"
//===========================================================================
//                             STATIC DATA
//===========================================================================
static ncs_hdl hDev = 0; // stores device handle
						 //===========================================================================
						 // Example error handling functions
						 //===========================================================================
void HandleError(long ErrorCode)
{
	//
	// The application could implement the error handling code here. I.e.
	// it could translate the error code into a human readable error message
	// string and display it. The following function call returns an error
	// message string in ErrMsg.
	//
	static char ErrMsg[64];
	NCS_GetErrorMsg(ErrorCode, ErrMsg, sizeof(ErrMsg));

	//
	// Display error message now
	//
}
//===========================================================================
// neMESYS Initialisation
//===========================================================================
long InitNemesysDev(void)
{
	long ErrCode;

	//
	// First we try to connect to device - this will execute a scan for 
	// connected dosing units and if everything is o.k. then we get a 
	// valid device handle returned.
	//  
	ErrCode = NCS_OpenDevice(true, &hDev);
	if (ERR_NOERR != ErrCode)
	{
		HandleError(ErrCode);
	}

	return ErrCode;
}
//===========================================================================
// Closing connection
//===========================================================================
long CloseNemesysDev(void)
{
	long ErrCode;
	//
	// We only need to close the connection if we have a valid device handle
	// obtained from NCS_OpenDevice().
	//
	if (hDev)
	{
		ErrCode = NCS_CloseDevice(hDev);
		if (ERR_NOERR != ErrCode)
		{
			HandleError(ErrCode);
		}
	}
	return ErrCode;
}
int main()
{
	InitNemesysDev();
	CloseNemesysDev();
	return 0;
}

//---------------------------------------------------------------------------
// EOF
